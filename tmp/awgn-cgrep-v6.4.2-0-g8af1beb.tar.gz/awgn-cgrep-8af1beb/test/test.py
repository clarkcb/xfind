# 
# Lorem ipsum dolor sit. Amet perferendis metus feugiat. Suspendisse massa egestas quam. 
# Morbi vivamus dolor nisl mauris ultricies molestie lacus. Proin ad nullam id integer.
# 

print """Sed etiam a suspendisse. \"Aliquam nulla erat risus. """
print '''Sed etiam a suspendisse. "Aliquam nulla erat risus. '''

print "Sed etiam a suspendisse. \"Aliquam nulla erat risus.\"";
print 'Sed etiam a suspendisse. "Aliquam nulla erat risus."';



